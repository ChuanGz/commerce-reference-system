using UserService.Application.Queries;
using UserService.Domain.Entities;

public class GetAllUsersQueryHandler : IRequestHandler<GetAllUsersQuery, List<User>>
{
    private readonly IUserRepository _repo;

    public GetAllUsersQueryHandler(IUserRepository repo)
    {
        _repo = repo;
    }

    public Task<List<User>> Handle(GetAllUsersQuery request, CancellationToken cancellationToken) =>
        _repo.GetAllAsync();
}
