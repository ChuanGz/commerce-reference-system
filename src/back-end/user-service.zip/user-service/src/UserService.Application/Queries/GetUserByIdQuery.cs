public record GetUserByIdQuery(Guid Id) : IRequest<User?>;
