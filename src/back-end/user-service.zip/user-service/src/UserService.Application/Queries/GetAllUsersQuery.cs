public record GetAllUsersQuery() : IRequest<List<User>>;
