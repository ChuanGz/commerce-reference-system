public record DeleteUserCommand(Guid Id) : IRequest;
